import{j as o}from"./framer-DMQMcxpe.js";import{P as r}from"./index-TxcEcFGX.js";import"./vendor-C95RmFyg.js";import"./ui-b2pgAQSi.js";function p(){return o.jsx(r,{})}export{p as default};
