import{j as o}from"./framer-DMQMcxpe.js";import{P as r}from"./index-BVgxGGAm.js";import"./vendor-C95RmFyg.js";import"./ui-TryzN4D6.js";function p(){return o.jsx(r,{})}export{p as default};
