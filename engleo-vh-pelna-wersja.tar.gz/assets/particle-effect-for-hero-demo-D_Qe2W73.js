import{j as o}from"./framer-IXC41IOq.js";import{P as r}from"./index-DqIDNlkg.js";import"./vendor-DIw92EAC.js";import"./ui-CFGsYciu.js";function p(){return o.jsx(r,{})}export{p as default};
