═══════════════════════════════════════════════════════════════════
              STRONA ENGLEO - INSTRUKCJA WDROŻENIA
═══════════════════════════════════════════════════════════════════

✅ PEŁNA WERSJA Z CONVEX BACKEND

═══════════════════════════════════════════════════════════════════
SZYBKI START DLA v101.vh.net.pl:
═══════════════════════════════════════════════════════════════════

1. Wgraj WSZYSTKIE pliki z tego folderu do public_html

2. Upewnij się że są następujące pliki:
   ✓ index.html
   ✓ .htaccess (MUSI BYĆ! może być ukryty)
   ✓ folder assets/ (wszystkie pliki JS i CSS)
   ✓ logo.png
   ✓ manifest.webmanifest

3. Wejdź na http://v101.vh.net.pl - strona działa!

═══════════════════════════════════════════════════════════════════
CO JEST WAŻNE:
═══════════════════════════════════════════════════════════════════

⚠️  PLIK .htaccess MUSI BYĆ WGRANY!
    - Może być ukryty
    - Włącz "Show hidden files" w File Managerze
    - Bez niego routing nie będzie działał (404 na podstronach)

⚠️  CONVEX BACKEND
    - Backend działa w chmurze (nie na Twoim hostingu)
    - URL: https://lovely-platypus-213.convex.cloud
    - Formularz kontaktowy zapisuje wiadomości do bazy Convex
    - Dashboard: https://dashboard.convex.dev

═══════════════════════════════════════════════════════════════════
CO DZIAŁA:
═══════════════════════════════════════════════════════════════════

✅ Wszystkie animacje (particle effect, 3D galeria)
✅ Dark/Light mode toggle
✅ Formularz kontaktowy z zapisem do bazy
✅ Routing (/, /gallery, /privacy-policy, itp.)
✅ Responsive design (mobile + desktop)
✅ Cookie consent banner

═══════════════════════════════════════════════════════════════════
TESTOWANIE:
═══════════════════════════════════════════════════════════════════

Po wgraniu sprawdź:

☐ Strona się ładuje na v101.vh.net.pl
☐ Particle effect reaguje na myszkę
☐ Podstrony działają (wejdź na /gallery)
☐ Odświeżenie (F5) na podstronie nie daje 404
☐ Formularz wysyła wiadomości (sprawdź toast)
☐ Dark mode działa
☐ Mobile - otwórz na telefonie

═══════════════════════════════════════════════════════════════════
PROBLEMY?
═══════════════════════════════════════════════════════════════════

Problem: 404 na podstronach
→ Sprawdź czy .htaccess jest wgrany
→ Zapytaj support czy mod_rewrite jest włączony

Problem: Brak stylów
→ Sprawdź czy folder assets/ jest wgrany
→ Wyczyść cache (Ctrl+Shift+R)

Problem: Formularz nie działa
→ Otwórz Console (F12) i zobacz błędy
→ Sprawdź czy hosting pozwala na HTTPS do convex.cloud

═══════════════════════════════════════════════════════════════════
SZCZEGÓŁOWA INSTRUKCJA:
═══════════════════════════════════════════════════════════════════

Zobacz plik w głównym folderze projektu:
→ INSTRUKCJA_HOSTING_Z_CONVEX.md

Tam znajdziesz:
- Krok po kroku instrukcję
- Troubleshooting
- Informacje o Convex
- Konfigurację email notifications

═══════════════════════════════════════════════════════════════════
STRUKTURA PLIKÓW:
═══════════════════════════════════════════════════════════════════

public_html/
├── index.html          ← Główny plik
├── .htaccess           ← Routing (WAŻNE!)
├── assets/             ← JS, CSS, fonty
│   ├── index-*.js
│   ├── index-*.css
│   ├── vendor-*.js
│   ├── framer-*.js
│   └── ...
├── logo.png
└── manifest.webmanifest

═══════════════════════════════════════════════════════════════════
KONTAKT:
═══════════════════════════════════════════════════════════════════

Formularz wysyła na: kontakt@engleo.pl
Telefon: +48 123 456 789

Wiadomości są zapisywane w bazie Convex.
Sprawdź je na: https://dashboard.convex.dev

═══════════════════════════════════════════════════════════════════

Powodzenia! 🚀

Strona jest w 100% gotowa i działająca z pełnym backendem.

═══════════════════════════════════════════════════════════════════
