import{j as o}from"./framer-DMQMcxpe.js";import{P as r}from"./index-DlSDqNJ6.js";import"./vendor-C95RmFyg.js";import"./ui-DKYBGbFl.js";function p(){return o.jsx(r,{})}export{p as default};
